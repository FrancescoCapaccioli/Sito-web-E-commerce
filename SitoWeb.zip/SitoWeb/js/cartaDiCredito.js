function cartaDiCredito() {
  document.getElementById('paypal').innerHTML =``
  document.getElementById('paypal').innerHTML =``
  document.getElementById('cartaCredit').innerHTML= `<form class="pagamento">
  <fieldset>
    <table>
      <tr>
       <td>
       <label>Nome</label>
       </td>
       <td>
       <label>Cognome</label>
       </td>
      </tr>
      <tr>
      <td>
       <input type="text" max="30" placeholder="nome">
      </td>
      <td>
      <input type="text" max="30" placeholder="Cognome">
  
      </td>
     </tr>
    </table>
</fieldset>
<br>
<fieldset>
  
  <label>Città</label>
  <br>
  <input type="text" max="30" placeholder="città">
  <br>
  <label for="floatingSelectGrid">Stato</label>
  <select class="form-select" id="floatingSelectGrid">
    <option selected>Italia</option>
    <option value="1" >Germania</option>
    <option value="2">Inghilterra</option>
    <option value="3">Stati Uniti</option>
    <option value="4" >Spagna</option>
    <option value="5">Canada</option>
  </select>


</fieldset>
<br>
<fieldset>
  <table>
   <tr>
     <td>
       <label>Indirizzo</label>
      </td>
      <td>
       <label>codice postale</label>
       </td>
    </tr>
    <tr>
     <td>
        <input type="text" max="30" placeholder="Indirizzo">
     </td>
     <td>
         <input type="text" max="30" placeholder="codice postale">
     </td>
    </tr>
  </table>
</fieldset>
<br>
<fieldset>
<table>
<tr>
  <td>
  <label>Numero carta</label>
   </td>
   <td>
   <label>Codice di sicurezza</label>
    </td>
    <td>
    <label>Data di scadenza</label>
    </td>
 </tr>
 <tr>
  <td>
  <input type="text" max="30" placeholder="Numero carta">
  </td>
  <td>
  <input type="text" max="4" placeholder="Codice di sicurezza">
  </td>
  <td>
  <input type="date" name="data di scadenza"> 
  </td>
 </tr>
</table>
  
   
</fieldset>
</table>
<br>
<a href="grazie.html"><button type="button" class="btn btn-primary">Procedi con il pagamento</button></a>
</form>`
}
function selezionaMetodoPagamento() {
var metodoPagamento = document.getElementById('floatingSelectGrid').value;

if (metodoPagamento === "1") {
  paypal();
} else if (metodoPagamento === "2") {
  giftCard();
} else {
  cartaDiCredito();
}
}
function  paypal(){
document.getElementById('paypal').innerHTML = `<form class="pagamento">
  <fieldset>
    <table>
      <tr>
       <td>
       <label>Nome</label>
       </td>
       <td>
       <label>Cognome</label>
       </td>
      </tr>
      <tr>
      <td>
       <input type="text" max="30" placeholder="nome">
      </td>
      <td>
      <input type="text" max="30" placeholder="Cognome">
  
      </td>
     </tr>
    </table>
</fieldset>
<br>
<fieldset>
  <br>
  <label for="floatingSelectGrid">Stato</label>
  <select class="form-select" id="floatingSelectGrid">
    <option selected>Italia</option>
    <option value="1" >Germania</option>
    <option value="2">Inghilterra</option>
    <option value="3">Stati Uniti</option>
    <option value="4" >Spagna</option>
    <option value="5">Canada</option>
  </select>


</fieldset>
<br>
<fieldset>
  <table>
   <tr>
     <td>
       <label>Mail account paypal</label>
      </td>
      <td>
       <label>password</label>
       </td>
    </tr>
    <tr>
     <td>
        <input type="mail" max="30" placeholder="mail">
     </td>
     <td>
         <input type="password" max="30">
     </td>
    </tr>
  </table>
</fieldset>
<br>
</table>
<a href="grazie.html"><button type="button" class="btn btn-primary">Procedi con il pagamento</button></a>
</form>`;
  document.getElementById('gift').innerHTML = ``;
  document.getElementById('cartaCredit').innerHTML =  ``

}
function giftCard(){
  document.getElementById('paypal').innerHTML =``
  document.getElementById('gift').innerHTML = `<form class="pagamento">
  <table>
  <tr>
    <td>
      <label>Inserisci il codice regalo</label>
     </td>
   </tr>
   <tr>
     <td>
        <input type="text" max="30" placeholder="codice">
     </td>
    </tr>
    <tr>
    <td>
    <a href="grazie.html"><button type="button" class="btn btn-primary">Procedi con il pagamento</button></a>
    </td>
    </tr>
   </table
   
  </form>`;
  document.getElementById('cartaCredit').innerHTML =  ``;
}