
function aggiungi1(){
    localStorage.setItem('indice1', 'true');
}
function aggiungi2(){
    localStorage.setItem('indice2', 'true');
}
function aggiungi3(){
    localStorage.setItem('indice3', 'true');
}
function aggiungi4(){
    localStorage.setItem('indice4', 'true');
}
function aggiungi5(){
    localStorage.setItem('indice5', 'true');
}
function aggiungi6(){
    localStorage.setItem('indice6', 'true');
}
function aggiungi7(){
    localStorage.setItem('indice7', 'true');
}
function aggiungi8(){
    localStorage.setItem('indice8', 'true');
}
function aggiungi9(){
    localStorage.setItem('indice9', 'true');
}
function aggiungi10(){
    localStorage.setItem('indice10', 'true');
}
function aggiungi11(){
    localStorage.setItem('indice11', 'true');
}
function aggiungi12(){
    localStorage.setItem('indice12', 'true');
}
function carrello(){
    var indice1 = localStorage.getItem('indice1');
    var indice2 = localStorage.getItem('indice2');
    var indice3 = localStorage.getItem('indice3');
    var indice4 = localStorage.getItem('indice4');
    var indice5 = localStorage.getItem('indice5');
    var indice6 = localStorage.getItem('indice6');
    var indice7 = localStorage.getItem('indice7');
    var indice8 = localStorage.getItem('indice8');
    var indice9 = localStorage.getItem('indice9');
    var indice10 = localStorage.getItem('indice10');
    var indice11 = localStorage.getItem('indice11');
    var indice12 = localStorage.getItem('indice12');
    somma=0.0;
    if(indice1!=null){
        document.getElementById('prod1').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(1)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/laptop1-removebg-preview.png">
      </td>
      <td>
      Chromebook Go
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot1()" id="input1"  placeholder="1">
     </form>
      </td> 
      <td>
         266.00€
      </td>`
      somma+=266.0;
    }   
    if(indice2!=null){
        document.getElementById('prod2').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(2)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/laptop2-removebg-preview.png">
      </td>
      <td>
      HP 250 G9 Computer portatile
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot2()" id="input2"  placeholder="1">
     </form>
      </td> 
      <td>
      395.00€
      </td>`
      somma+=395.0;
    }
    if(indice3!=null){
        document.getElementById('prod3').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(3)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/laptop3-removebg-preview.png">
      </td>
      <td>
      MSI Thin GF63 12UDX-293IT
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot3()" id="input3"  placeholder="1">
     </form>
      </td> 
      <td>
      1349.00€
      </td>`
      somma+=1349.0;
    }
    if(indice4!=null){
        document.getElementById('prod4').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(4)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/pc1.png">
      </td>
      <td>
      Greed® Ultra V2 PC fisso
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot4()" id="input4"  placeholder="1">
     </form>
      </td> 
      <td>
      759.90€
      </td>`
      somma+=759.90;
    }
    if(indice5!=null){
        document.getElementById('prod5').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(5)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/pc2.png">
      </td>
      <td>
      HP 250 G9 Computer portatile
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot5()" id="input5"  placeholder="1">
     </form>
      </td> 
      <td>
      519,00€
      </td>`
      somma+=519.0;
    }
    if(indice6!=null){
        document.getElementById('prod6').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(6)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/pc3.png">
      </td>
      <td>
      Pc Fisso i7 intel core Cpu fino a 3.90ghz
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot6()" id="input6"  placeholder="1">
     </form>
      </td> 
      <td>
      279.90€
      </td>`
      somma+=279.90;  
    }
    if(indice7!=null){
        document.getElementById('prod7').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(7)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/tastiera.png">
      </td>
      <td>
      Logitech G213 Prodigy Tastiera
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot7()" id="input7"  placeholder="1">
     </form>
      </td> 
      <td>
      59.99€
      </td>`
      somma+=59.99;
    }
    if(indice8!=null){
        document.getElementById('prod8').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(8)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/mouse.png">
      </td>
      <td>
      Logitech G G502 HERO Mouse
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot8()" id="inpu8"  placeholder="1">
     </form>
      </td> 
      <td>
      92.99€
      </td>`
      somma+=92.99;
    }
    if(indice9!=null){
        document.getElementById('prod9').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(9)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/cuffie.png">
      </td>
      <td>
      Logitech G733 Lightspeed
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot9()" id="input9"  placeholder="1">
     </form>
      </td> 
      <td>
      169,00€
      </td>`
      somma+=169,0;
    }
    if(indice10!=null){
        document.getElementById('prod10').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(10)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/ssd.png">
      </td>
      <td>
      Crucial MX500
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot10()" id="input10"  placeholder="1">
     </form>
      </td> 
      <td>
      69.99€
      </td>`
      somma+=69.99;
    }
    if(indice11!=null){
        document.getElementById('prod11').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(11)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/ram.png">
      </td>
      <td>
      Corsair Vengeance RGB PRO
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot11()" id="input11"  placeholder="1">
     </form>
      </td> 
      <td>
      96.12€
      </td>`
      somma+=96.12;
    }
    if(indice12!=null){
        document.getElementById('prod12').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(12)" onclick="rimuovi(1)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/processore.png">
      </td>
      <td>
      AMD Ryzen 9 5900X
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot12()" id="input12"  placeholder="1">
     </form>
      </td> 
      <td>
      559.98€
      </td>`
      somma+=559.98;
    }
    document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
    <br>
    <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}

function aggiornaTot1(){
    const input = document.getElementById("input1");
    const inputValue = input.value;
    totale=inputValue*266.0;
   document.getElementById('prod1').innerHTML = `<td>
        <a href="#" onclick="rimuovi(1)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/laptop1-removebg-preview.png">
      </td>
      <td>
      Chromebook Go
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot1()" id="input1" placeholder="${inputValue}">
     </form>
      </td> 
      <td>
         ${totale},00€
      </td>`
      localStorage.setItem('input1', inputValue);
      somma-=266;
      somma+=totale;
      document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
      <br>
      <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot2(){
    const input = document.getElementById("input2");
    const inputValue = input.value;
    totale=inputValue*  395.0;
    document.getElementById('prod2').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(2)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/laptop2-removebg-preview.png">
  </td>
  <td>
  HP 250 G9 Computer portatile
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot2()" id="input2"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale},00€
  </td>`
  localStorage.setItem('input2', inputValue);
  somma-=395;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot3(){
    const input = document.getElementById("input3");
    const inputValue = input.value;
    totale=inputValue*  1349.0;
    document.getElementById('prod3').innerHTML = `     <td>
        <a href="#" onclick="rimuovi(3)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
        </svg></a>
      </td>
      <td>
      <img src="../img/laptop3-removebg-preview.png">
      </td>
      <td>
      MSI Thin GF63 12UDX-293IT
      </td>
      <td>
      <form>
      <input type="number" max="15" onchange="aggiornaTot3()" id="input3"  placeholder="${inputValue}">
     </form>
      </td> 
      <td>
      ${totale}€
      </td>`
      localStorage.setItem('input3', inputValue);
      somma-= 1349.0;
      somma+=totale;
      document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
      <br>
      <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot4(){
    const input = document.getElementById("input4");
    const inputValue = input.value;
    totale=inputValue*  759.90;

    document.getElementById('prod4').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(4)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/pc1.png">
  </td>
  <td>
  Greed® Ultra V2 PC fisso
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot4()" id="input4"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`
  localStorage.setItem('input4', inputValue);
  somma-= 759.90;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot5(){
    const input = document.getElementById("input5");
    const inputValue = input.value;
    totale=inputValue*    519.0;
    document.getElementById('prod5').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(5)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/pc2.png">
  </td>
  <td>
  HP 250 G9 Computer portatile
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot5()" id="input5"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`
  localStorage.setItem('input5', inputValue);
  somma-= 519.0;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot6(){
    const input = document.getElementById("input6");
    const inputValue = input.value;
    totale=inputValue*    279.90;
    document.getElementById('prod6').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(6)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/pc3.png">
  </td>
  <td>
  Pc Fisso i7 intel core Cpu fino a 3.90ghz
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot6()" id="input6"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`
  localStorage.setItem('input6', inputValue);
  somma-= 279.90;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot7(){
    const input = document.getElementById("input7");
    const inputValue = input.value;
    totale=inputValue*     59.99;
    document.getElementById('prod7').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(7)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/tastiera.png">
  </td>
  <td>
  Logitech G213 Prodigy Tastiera
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot7()" id="input7"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`
  localStorage.setItem('input7', inputValue);
  somma-=   59.99;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot8(){
    const input = document.getElementById("input8");
    const inputValue = input.value;
    totale=inputValue*      92.99;
    document.getElementById('prod8').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(8)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/mouse.png">
  </td>
  <td>
  Logitech G G502 HERO Mouse
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot8()" id="inpu8"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`
  localStorage.setItem('input8', inputValue);
  somma-=  92.99;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot9(){
    const input = document.getElementById("input9");
    const inputValue = input.value;
    totale=inputValue*      169.0;
    document.getElementById('prod9').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(9)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/cuffie.png">
  </td>
  <td>
  Logitech G733 Lightspeed
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot9()" id="input9"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`
  localStorage.setItem('input9', inputValue);
  somma-= 169.0;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot10(){
    const input = document.getElementById("input10");
    const inputValue = input.value;
    totale=inputValue*     69.99;
    document.getElementById('prod10').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(10)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/ssd.png">
  </td>
  <td>
  Crucial MX500
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot10()" id="input10"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`
  localStorage.setItem('input10', inputValue);
  somma-=  69.99;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot11(){
    const input = document.getElementById("input11");
    const inputValue = input.value;
    totale=inputValue*       96.12;
    document.getElementById('prod11').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(11)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/ram.png">
  </td>
  <td>
  Corsair Vengeance RGB PRO
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot11()" id="input11"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`
  localStorage.setItem('input11', inputValue);
  somma-=  96.12;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`
}
function aggiornaTot12(){
    const input = document.getElementById("input12");
    const inputValue = input.value;
    totale=inputValue*       559.98;
    document.getElementById('prod12').innerHTML = `     <td>
    <a href="#" onclick="rimuovi(12)"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
      <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
      <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708"/>
    </svg></a>
  </td>
  <td>
  <img src="../img/processore.png">
  </td>
  <td>
  AMD Ryzen 9 5900X
  </td>
  <td>
  <form>
  <input type="number" max="15" onchange="aggiornaTot12()" id="input12"  placeholder="${inputValue}">
 </form>
  </td> 
  <td>
  ${totale}€
  </td>`;
  localStorage.setItem('input12', inputValue);
  somma-= 559.98;
  somma+=totale;
  document.getElementById('total').innerHTML =`<h3>Totale: ${somma}€</h3> 
  <br>
  <a href="cartaCredito.html"><button type="button" class="btn btn-primary">Acquista</button></a>`;
}
function rimuovi(num){
    document.getElementById(`prod${num}`).innerHTML=``;
    localStorage.removeItem(`indice${num}`);

}
function mandaEmail(){
  var nome = document.getElementById('nome').value;
  var cognome = document.getElementById('cognome').value;
  var email = document.getElementById('email').value;
  var feedback = document.getElementById('feedback').value;
  var messaggio = 'nome '+ nome + '<br>Cognome'+ cognome +"<br>Email"+ email + "<br>Feedback: "+feedback;

  Email.send({
  

    Host : "smtp.elasticemail.com",
    Username : "trumotrumo30@gmail.com",
    Password : "C002D42DE5851FCE84C27401C63C195CCC7F",
    To : 'trumotrumo30@gmail.com',
    From : "trumotrumo30@gmail.com",
    Subject : "Feedback",
    Body : messaggio
}).then(
  message =>{
    if(message=='OK'){
      swal("Email mandata con successo", "success");
    }else{
      swal("errore", "error");
    }
  }
);
}
